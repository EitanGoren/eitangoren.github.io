# My New Website
![GitHub last commit](https://img.shields.io/github/last-commit/eitangoren/eitangoren.github.io) ![GitHub commits since latest release (by date) for a branch](https://img.shields.io/github/commits-since/eitangoren/eitangoren.github.io/v1.0)

## Features
- Fully responsive
- Modern design
- Portfolio
- Up to date
- Social links

## About

This website was built in 2 weeks.
Thanks to the great <a href="https://bootstrapstudio.io/"> <strong> Bootsrap Studio </strong> </a> software.<br>
The graphics were designed by me, based on templates I took from <a href="https://www.canva.com/"> <strong>Canva</strong></a>.<br>

## Images
<img src="/assets/img/website.jpg" width="850" height="400" >

